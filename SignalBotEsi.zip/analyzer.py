
import requests
import pandas as pd
import ta

def fetch_ohlcv(symbol, interval='1min', limit=100):
    url = f"https://api.coinex.com/v1/market/kline?market={symbol}&type={interval}&limit={limit}"
    r = requests.get(url)
    data = r.json()['data']
    df = pd.DataFrame(data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['close'] = pd.to_numeric(df['close'])
    return df

def analyze_market(symbol):
    try:
        df = fetch_ohlcv(symbol, '5min', 100)

        rsi = ta.momentum.RSIIndicator(df['close'], window=14).rsi().iloc[-1]
        macd = ta.trend.MACD(df['close'])
        macd_diff = macd.macd_diff().iloc[-1]
        bb = ta.volatility.BollingerBands(df['close'])
        bb_high = bb.bollinger_hband().iloc[-1]
        bb_low = bb.bollinger_lband().iloc[-1]
        price = df['close'].iloc[-1]

        signal = "Unknown"
        if rsi < 30 and macd_diff > 0:
            signal = "Buy Signal"
        elif rsi > 70 and macd_diff < 0:
            signal = "Sell Signal"
        else:
            signal = "Hold / Wait"

        return (
            f"Market: {symbol}\n"
            f"Price: {price:.2f}\n"
            f"RSI: {rsi:.2f}\n"
            f"MACD Diff: {macd_diff:.4f}\n"
            f"Bollinger Range: {bb_low:.2f} - {bb_high:.2f}\n"
            f"Signal: {signal}"
        )

    except Exception as e:
        return f"Analysis error: {str(e)}"
