
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from analyzer import analyze_market
from user_config import USERS
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

async def signal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in USERS:
        await update.message.reply_text("دسترسی غیرمجاز")
        return
    if len(context.args) != 1:
        await update.message.reply_text("استفاده صحیح: /signal BTCUSDT")
        return

    symbol = context.args[0].upper()
    await update.message.reply_text("در حال تحلیل...")

    result = analyze_market(symbol)
    await update.message.reply_text(result)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("/signal [symbol] - دریافت سیگنال لحظه‌ای\n/help - راهنما")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("signal", signal))
app.add_handler(CommandHandler("help", help_command))

if __name__ == "__main__":
    app.run_polling()
