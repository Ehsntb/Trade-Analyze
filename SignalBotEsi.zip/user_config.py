
USERS = {
    123456789: {
        "name": "Esi",
        "access_level": "signal_only"
    }
}
